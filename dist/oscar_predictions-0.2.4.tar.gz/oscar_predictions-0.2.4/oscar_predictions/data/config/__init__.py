"""Bundled configuration text assets."""
