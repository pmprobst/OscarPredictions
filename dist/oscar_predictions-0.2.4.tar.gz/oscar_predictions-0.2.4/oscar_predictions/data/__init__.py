"""Bundled package data namespace."""
